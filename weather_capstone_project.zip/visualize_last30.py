"""
Visualize last 30 days (rolling up hourly/daily) for a single city.
Usage: python visualize_last30.py --city "Mumbai"
"""
import argparse, json
import psycopg2
import pandas as pd
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

with open('config.json') as f:
    cfg = json.load(f)
DB = cfg['postgres']

def get_conn():
    return psycopg2.connect(
        host=DB['host'], port=DB.get('port',5432),
        user=DB['user'], password=DB['password'], dbname=DB['database']
    )

def load_last_n_days(city, n=30):
    conn = get_conn()
    query = """
    SELECT observation_time AT TIME ZONE 'UTC' as obs_time, temp_c, humidity, pressure
    FROM weather_observations
    WHERE city = %s AND observation_time >= %s
    ORDER BY observation_time ASC
    """
    since = datetime.utcnow() - timedelta(days=n)
    df = pd.read_sql(query, conn, params=(city, since))
    conn.close()
    return df

def plot_city(df, city):
    if df.empty:
        print('No data for', city)
        return
    df['obs_time'] = pd.to_datetime(df['obs_time'])
    df = df.set_index('obs_time').resample('D').mean().dropna()
    plt.figure(figsize=(10,5))
    plt.plot(df.index, df['temp_c'], marker='o')
    plt.title(f'Average daily temperature (°C) - last {len(df)} days')
    plt.xlabel('Date'); plt.ylabel('Temp (°C)')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f'plot_{city.replace(" ","_")}_last30.png')
    print('Saved plot to', f'plot_{city.replace(" ","_")}_last30.png')

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--city', required=True)
    args = parser.parse_args()
    df = load_last_n_days(args.city, n=30)
    plot_city(df, args.city)
