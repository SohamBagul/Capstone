# How to push this project to GitHub (steps)

1. Create a new repository on GitHub (do NOT initialize with README).
2. In your project folder:
   git init
   git add .
   git commit -m "Initial commit - weather capstone project"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main

3. After pushing, copy the repo URL and paste it into `Project_Report.md` under GitHub URL section.
4. Convert `Project_Report.md` to PDF:
   - Using pandoc: pandoc Project_Report.md -o Project_Report.pdf
   - Or use VSCode or online markdown-to-pdf converters.

5. Submit the `Project_Report.pdf` as your final report and provide the GitHub URL to your instructor.
