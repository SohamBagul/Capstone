"""
Simple ML forecasting using lag features and sklearn models.
"""
import argparse, json
import pandas as pd, numpy as np
import psycopg2
from datetime import datetime, timedelta
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib

with open('config.json') as f:
    cfg = json.load(f)
DB = cfg['postgres']

def get_conn():
    return psycopg2.connect(
        host=DB['host'], port=DB.get('port',5432),
        user=DB['user'], password=DB['password'], dbname=DB['database']
    )

def load_city(city, days=90):
    conn = get_conn()
    since = datetime.utcnow() - timedelta(days=days)
    df = pd.read_sql("""SELECT observation_time AT TIME ZONE 'UTC' as obs_time, temp_c FROM weather_observations WHERE city=%s AND observation_time >= %s ORDER BY observation_time ASC""", conn, params=(city, since))
    conn.close()
    df['obs_time'] = pd.to_datetime(df['obs_time'])
    df = df.set_index('obs_time').resample('H').mean().interpolate()  # hourly
    return df

def create_lag_features(df, lags=24):
    for lag in range(1, lags+1):
        df[f'lag_{lag}'] = df['temp_c'].shift(lag)
    df = df.dropna()
    return df

def train_and_forecast(city):
    df = load_city(city, days=60)
    if df.empty or len(df) < 100:
        print('Not enough data to train for', city)
        return
    df_feat = create_lag_features(df, lags=24)
    X = df_feat.drop(columns=['temp_c'])
    y = df_feat['temp_c']

    # train/test split
    split = int(0.8 * len(X))
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y.iloc[:split], y.iloc[split:]

    models = {
        'linear': LinearRegression(),
        'rf': RandomForestRegressor(n_estimators=100, n_jobs=-1, random_state=42)
    }
    results = {}
    for name, m in models.items():
        m.fit(X_train, y_train)
        preds = m.predict(X_test)
        mse = mean_squared_error(y_test, preds)
        results[name] = {'model': m, 'mse': mse}
        joblib.dump(m, f'model_{city}_{name}.joblib')
        print(f'Trained {name} model, MSE={mse:.4f}')

    # Naive persistence (last value)
    last_temp = df['temp_c'].iloc[-1]
    print('Naive persistence (last observed temp):', last_temp)
    print('Model results:', {k:v['mse'] for k,v in results.items()})

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--city', required=True)
    args = parser.parse_args()
    train_and_forecast(args.city)
