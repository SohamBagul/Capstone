# Weather Data Capstone Project

This repository contains code to:
1. Fetch live weather data from a public API (OpenWeatherMap recommended) and store it in PostgreSQL.
2. Create required PostgreSQL databases/tables.
3. Visualize weather data for a single city (analysis of last 30 days).
4. Build basic ML models to forecast weather (temperature) for short horizons.

**IMPORTANT**: Fill in your OpenWeatherMap API key and PostgreSQL credentials in `config.json` before running the scripts.

## Files
- `config.json` - configuration template (add API key and DB creds).
- `db_setup.sql` - SQL statements to create database and tables.
- `fetch_weather.py` - script to fetch current weather for a list of cities and insert into DB.
- `etl_store.py` - helper ETL script (same as fetch script, included for clarity).
- `visualize_last30.py` - script to visualize last 30 days for a specific city.
- `ml_forecast.py` - simple ML forecast scripts (Linear Regression, RandomForest, and a naive AR-like model using lag features).
- `requirements.txt` - required Python packages.
- `Project_Report.md` - project report (can be converted to PDF).
- `push_to_github_instructions.md` - step-by-step Git commands to upload to GitHub.
- `LICENSE` - MIT License.

## Quick setup
1. Create a virtual environment: `python -m venv venv && source venv/bin/activate` (Windows: `venv\\Scripts\\activate`)
2. Install requirements: `pip install -r requirements.txt`
3. Edit `config.json` with PostgreSQL connection and API key.
4. Run DB setup: `psql -h <host> -U <user> -f db_setup.sql`
5. Start fetching data (ideally run as cron or scheduler): `python fetch_weather.py`
6. Visualize last 30 days: `python visualize_last30.py --city "London"`
7. Run ML forecast: `python ml_forecast.py --city "London"`

See `Project_Report.md` for details, methodology, and how to convert to PDF.
