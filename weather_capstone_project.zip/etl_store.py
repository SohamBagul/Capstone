# Helper ETL - identical to fetch_weather, kept for modularity.
from fetch_weather import fetch_city, get_conn, insert_observation
