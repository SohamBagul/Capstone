# Capstone Project: Weather Data Collection, Visualization & Forecasting

## Objectives
1. Fetch live weather data from a public API and store it in PostgreSQL.
2. Create databases and tables in PostgreSQL to store observations.
3. Implement visualization for a single city analyzing the last 30 days.
4. Apply basic ML models for short-term weather forecasting and present results.
5. Provide working code and upload repository to GitHub; include the URL in the PDF submission.

## Methodology
- Use OpenWeatherMap's Current Weather API to fetch real-time observations. (Requires an API key.)
- Store raw JSON and normalized fields (temperature, humidity, pressure, wind, timestamp) in a PostgreSQL table.
- Run scheduled ingestion at a suitable interval (e.g., every 30 minutes) to accumulate historical data.
- For visualization, extract the last 30 days of observations, resample to daily averages, and plot temperature trends.
- For forecasting, use lag features (previous 24 hours) and simple models: Linear Regression and Random Forest. Evaluate using MSE and persistence baseline.

## How to run
1. Edit `config.json` with your API key and PostgreSQL credentials.
2. Create DB and run `db_setup.sql`.
3. Install requirements and run `fetch_weather.py` regularly to accumulate data.
4. Produce visualizations: `python visualize_last30.py --city "Mumbai"`
5. Train models: `python ml_forecast.py --city "Mumbai"`

## GitHub URL
After you create a GitHub repository and push this code, add the GitHub URL here before converting to PDF. Example URL format:
`https://github.com/<your-username>/<repo-name>`

## Deliverables (what to include in your submission)
- PDF containing the Objectives, Methodology, Results (plots), GitHub URL, and sample outputs.
- Link to GitHub repo containing working code.
- Screenshots of plot images and model evaluation outputs (include in PDF).

## Notes
- Ensure you collect at least 30 days of data for the "last 30 days" analysis. If you don't have 30 days of historical data, you can backfill using OpenWeatherMap's One Call historical API (paid) or external datasets.
