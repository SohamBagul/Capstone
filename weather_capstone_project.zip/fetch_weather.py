"""
Fetch current weather for configured cities from OpenWeatherMap and insert into PostgreSQL.
"""
import requests, time, json, argparse
from datetime import datetime
import psycopg2

with open('config.json') as f:
    cfg = json.load(f)

API_KEY = cfg['openweathermap_api_key']
CITIES = cfg['cities']

DB_CFG = cfg['postgres']

BASE_URL = 'https://api.openweathermap.org/data/2.5/weather'

def get_conn():
    return psycopg2.connect(
        host=DB_CFG['host'],
        port=DB_CFG.get('port',5432),
        user=DB_CFG['user'],
        password=DB_CFG['password'],
        dbname=DB_CFG['database']
    )

def fetch_city(city):
    params = {'q': city, 'appid': API_KEY}
    r = requests.get(BASE_URL, params=params, timeout=15)
    r.raise_for_status()
    return r.json()

def insert_observation(conn, city, data):
    cur = conn.cursor()
    obs_time = datetime.utcfromtimestamp(data['dt'])
    main = data.get('main',{})
    wind = data.get('wind',{})
    weather = data.get('weather',[{}])[0]
    cur.execute("""
        INSERT INTO weather_observations
        (city, country, observation_time, temp_c, temp_k, feels_like, temp_min, temp_max,
         pressure, humidity, wind_speed, wind_deg, weather_main, weather_description, raw_json)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (
        city,
        data.get('sys',{}).get('country'),
        obs_time,
        main.get('temp') - 273.15 if main.get('temp') is not None else None,
        main.get('temp'),
        main.get('feels_like'),
        main.get('temp_min'),
        main.get('temp_max'),
        main.get('pressure'),
        main.get('humidity'),
        wind.get('speed'),
        wind.get('deg'),
        weather.get('main'),
        weather.get('description'),
        json.dumps(data)
    ))
    conn.commit()
    cur.close()

def main(poll=False, interval_minutes=30):
    conn = get_conn()
    try:
        while True:
            for city in CITIES:
                try:
                    data = fetch_city(city)
                    insert_observation(conn, city, data)
                    print(f"Inserted observation for {city} at {datetime.utcnow().isoformat()}Z")
                except Exception as e:
                    print('Error fetching/inserting for', city, e)
            if not poll:
                break
            time.sleep(interval_minutes*60)
    finally:
        conn.close()

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--poll', action='store_true', help='Run continuously')
    parser.add_argument('--interval', type=int, default=cfg.get('poll_interval_minutes',30))
    args = parser.parse_args()
    main(poll=args.poll, interval_minutes=args.interval)
