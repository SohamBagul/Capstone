-- Create database (run as a superuser or create db via psql)
-- CREATE DATABASE weather_db;

-- Connect to weather_db and run the following
CREATE TABLE IF NOT EXISTS weather_observations (
    id SERIAL PRIMARY KEY,
    city VARCHAR(128) NOT NULL,
    country VARCHAR(64),
    observation_time TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    temp_c REAL,
    temp_k REAL,
    feels_like REAL,
    temp_min REAL,
    temp_max REAL,
    pressure INTEGER,
    humidity INTEGER,
    wind_speed REAL,
    wind_deg INTEGER,
    weather_main VARCHAR(128),
    weather_description VARCHAR(256),
    raw_json JSONB,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

-- Index to speed up city + time queries
CREATE INDEX IF NOT EXISTS idx_city_observation_time ON weather_observations (city, observation_time);
